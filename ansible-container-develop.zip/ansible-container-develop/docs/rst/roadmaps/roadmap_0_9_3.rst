Roadmap for Release 0.9.3
=========================

- Create multiple, simple working examples similar to Jag's "Hello World" demo from AnsibleFest
- Get pre-baked conductor images (introduced in 0.9.2) passing RedHat Security Scan, and pushed into RedHat Container Catalog
- Create daily pre-bake, scanning, and pushing of images in Travis
