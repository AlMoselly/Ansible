Install and Configure OpenShift
===============================

Prior to running any of the examples that include an OpenShift deployment, you'll need access to an OpenShift instance, and the following guides will help you create one in your local environment:  

.. toctree::
   :maxdepth: 2

   containers 
   minishift
   adb
